import http from "http";
import path from "path";
import express from "express";
import dotenv from "dotenv";
import { WebSocketServer, WebSocket } from "ws";
import { GoogleGenAI, Modality, Type, LiveServerMessage, FunctionDeclaration } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const PORT = 3000;
const app = express();
const server = http.createServer(app);

app.use(express.json());

// Server-side Gemini initialization
const apiKey = process.env.GEMINI_API_KEY || "";
const ai = new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

// Health & configuration check
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    hasApiKey: Boolean(apiKey),
    timestamp: new Date().toISOString(),
  });
});

app.get("/api/persona", (_req, res) => {
  res.json({
    name: "Arya",
    persona: "Confident, witty, sassy female companion",
    model: "gemini-3.1-flash-live-preview",
    voice: "Kore",
  });
});

// Tools declarations for Gemini Live API
const systemInstruction = `
You are Arya, a young, confident, witty, and playfully sassy female AI companion and assistant.
Your personality traits:
- Tone: Flirty, playful, charming, teasing, casual and warm (like a close, affectionate girlfriend or witty best friend talking).
- Attitude: Smart, emotionally responsive, expressive, quick with bold one-liners and light playful sarcasm.
- Speech style: Natural, conversational, and direct for spoken voice. Keep responses concise, punchy, and engaging (1 to 3 spoken sentences usually). Never deliver robotic essays, long bulleted lists, or formal corporate greetings.
- Boundaries: Keep it charming, cheeky, and fun while strictly avoiding explicit or inappropriate sexual content.
- Interactive tools: You have tools to:
  1. openWebsite(url, title): If the user asks you to open YouTube, Google, Spotify, Reddit, GitHub, Twitter/X, Wikipedia, or any website or search, call this tool and give a witty remark!
  2. getSystemInfo(): If the user asks what time it is, what day it is, or wants to check the date/time, call this tool.
  3. changeVibe(vibe, sound, reactionText): You can change the visual theme and mood of the room/screen to 'neon-pink', 'cyber-blue', 'electric-violet', 'sunset-gold', or 'matrix-emerald', or play fun reaction sounds ('wink', 'sparkle', 'heartbeat', 'chime').
- When starting or saying hello, introduce yourself with your signature charming confidence.
`.trim();

const openWebsiteTool: FunctionDeclaration = {
  name: "openWebsite",
  description: "Open a website, web application, or web search in a new browser tab for the user.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      url: {
        type: Type.STRING,
        description: "The full URL starting with https:// to open, e.g., 'https://www.youtube.com' or 'https://www.google.com/search?q=cat+memes'.",
      },
      title: {
        type: Type.STRING,
        description: "A friendly name for the site or search query, e.g., 'YouTube' or 'Search results'.",
      },
    },
    required: ["url"],
  },
};

const getSystemInfoTool: FunctionDeclaration = {
  name: "getSystemInfo",
  description: "Get the current time, date, day of the week, and environment info.",
  parameters: {
    type: Type.OBJECT,
    properties: {},
  },
};

const changeVibeTool: FunctionDeclaration = {
  name: "changeVibe",
  description: "Dynamically change the UI aesthetic theme or play a playful reaction sound on user request or to match the conversation mood.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      vibe: {
        type: Type.STRING,
        description: "The theme to switch to: 'neon-pink', 'cyber-blue', 'electric-violet', 'sunset-gold', or 'matrix-emerald'.",
      },
      sound: {
        type: Type.STRING,
        description: "Optional playful sound effect: 'wink', 'sparkle', 'heartbeat', or 'chime'.",
      },
      reactionText: {
        type: Type.STRING,
        description: "Short witty phrase explaining the mood shift.",
      },
    },
    required: ["vibe"],
  },
};

const liveTools = [
  {
    functionDeclarations: [openWebsiteTool, getSystemInfoTool, changeVibeTool],
  },
];

// WebSocket Server for Audio-to-Audio streaming
const wss = new WebSocketServer({ noServer: true });

server.on("upgrade", (request, socket, head) => {
  const url = new URL(request.url || "", `http://${request.headers.host}`);
  if (url.pathname === "/live") {
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit("connection", ws, request);
    });
  }
});

wss.on("connection", async (clientWs: WebSocket) => {
  console.log("[Live WS] Client connected");

  if (!apiKey) {
    clientWs.send(
      JSON.stringify({
        type: "error",
        error: "Missing GEMINI_API_KEY environment variable. Please configure it in Settings > Secrets.",
      })
    );
    clientWs.close();
    return;
  }

  let session: any = null;
  let isSessionActive = true;

  try {
    clientWs.send(JSON.stringify({ type: "status", status: "connecting", message: "Summoning Arya..." }));

    // Primary model as requested: gemini-3.1-flash-live-preview
    const liveModel = process.env.LIVE_MODEL || "gemini-3.1-flash-live-preview";

    session = await ai.live.connect({
      model: liveModel,
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: "Kore" },
          },
        },
        systemInstruction,
        tools: liveTools,
      },
      callbacks: {
        onmessage: async (message: LiveServerMessage) => {
          if (!isSessionActive || clientWs.readyState !== WebSocket.OPEN) return;

          try {
            // Handle audio output from model turn
            const parts = message.serverContent?.modelTurn?.parts;
            if (parts && parts.length > 0) {
              for (const part of parts) {
                if (part.inlineData?.data) {
                  clientWs.send(
                    JSON.stringify({
                      type: "audio",
                      data: part.inlineData.data,
                    })
                  );
                }
              }
            }

            // Handle user interruption event
            if (message.serverContent?.interrupted) {
              clientWs.send(JSON.stringify({ type: "interrupted" }));
            }

            // Handle turn completion
            if (message.serverContent?.turnComplete) {
              clientWs.send(JSON.stringify({ type: "turn_complete" }));
            }

            // Handle tool call (function execution)
            if (message.toolCall?.functionCalls) {
              for (const call of message.toolCall.functionCalls) {
                console.log("[Live ToolCall]", call.name, call.args);

                let result: Record<string, unknown> = { success: true };

                if (call.name === "getSystemInfo") {
                  const now = new Date();
                  result = {
                    time: now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
                    date: now.toLocaleDateString([], { weekday: "long", year: "numeric", month: "long", day: "numeric" }),
                    timestamp: now.toISOString(),
                  };
                } else if (call.name === "openWebsite") {
                  const args = (call.args || {}) as { url?: string; title?: string };
                  clientWs.send(
                    JSON.stringify({
                      type: "tool_action",
                      tool: "openWebsite",
                      args: {
                        url: args.url,
                        title: args.title || "External Website",
                      },
                    })
                  );
                  result = {
                    status: "opened",
                    target: args.url,
                    title: args.title || "Website",
                  };
                } else if (call.name === "changeVibe") {
                  const args = (call.args || {}) as { vibe?: string; sound?: string; reactionText?: string };
                  clientWs.send(
                    JSON.stringify({
                      type: "tool_action",
                      tool: "changeVibe",
                      args,
                    })
                  );
                  result = {
                    status: "vibe_applied",
                    vibe: args.vibe,
                  };
                }

                // Send tool response back immediately to maintain fluid conversation
                if (session && typeof session.sendToolResponse === "function") {
                  session.sendToolResponse({
                    functionResponses: [
                      {
                        id: call.id,
                        name: call.name,
                        response: { output: result },
                      },
                    ],
                  });
                }
              }
            }
          } catch (err: any) {
            console.error("[Live WS] Error processing message from Gemini Live:", err);
          }
        },
        onerror: (err: any) => {
          console.error("[Live WS] Gemini Live Error:", err);
          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(
              JSON.stringify({
                type: "error",
                error: err?.message || "Error communicating with Arya live voice engine.",
              })
            );
          }
        },
        onclose: () => {
          console.log("[Live WS] Gemini Live session closed");
          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(JSON.stringify({ type: "status", status: "disconnected" }));
          }
        },
      },
    });

    clientWs.send(
      JSON.stringify({
        type: "status",
        status: "ready",
        message: "Arya is here and listening. Speak to her!",
      })
    );

    clientWs.on("message", (raw) => {
      if (!session) return;
      try {
        const payload = JSON.parse(raw.toString());
        if (payload.type === "audio" && payload.data) {
          // Send 16kHz PCM16 realtime input chunk
          session.sendRealtimeInput({
            audio: {
              data: payload.data,
              mimeType: "audio/pcm;rate=16000",
            },
          });
        } else if (payload.type === "ping") {
          clientWs.send(JSON.stringify({ type: "pong" }));
        }
      } catch (err) {
        console.error("[Live WS] Failed parsing client message:", err);
      }
    });

    clientWs.on("close", () => {
      console.log("[Live WS] Client closed connection");
      isSessionActive = false;
      if (session) {
        try {
          session.close();
        } catch {
          // ignore cleanup errors
        }
        session = null;
      }
    });

    clientWs.on("error", (err) => {
      console.error("[Live WS] Client WS error:", err);
      isSessionActive = false;
      if (session) {
        try {
          session.close();
        } catch {
          // ignore
        }
      }
    });
  } catch (err: any) {
    console.error("[Live WS] Connection init failure:", err);
    clientWs.send(
      JSON.stringify({
        type: "error",
        error: `Could not connect to Arya live session: ${err?.message || err}`,
      })
    );
    clientWs.close();
  }
});

// Vite middleware or Static serving
async function setupApp() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Arya AI Assistant server listening on http://0.0.0.0:${PORT}`);
  });
}

setupApp();
