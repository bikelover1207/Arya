/**
 * AudioStreamer manages 24kHz playback of Gemini Live audio chunks using Web Audio API.
 * Ensures gapless scheduling, real-time frequency analysis, and instant interruption clearing.
 */
export class AudioStreamer {
  private audioContext: AudioContext | null = null;
  private analyserNode: AnalyserNode | null = null;
  private freqData: Uint8Array = new Uint8Array(64);
  private nextStartTime = 0;
  private activeSources: AudioBufferSourceNode[] = [];
  private checkInterval: any = null;
  public onPlaybackStateChange?: (isPlaying: boolean) => void;

  private initContext(): void {
    if (!this.audioContext || this.audioContext.state === 'closed') {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      // Gemini Live outputs audio at 24kHz
      this.audioContext = new AudioContextClass({ sampleRate: 24000 });

      this.analyserNode = this.audioContext.createAnalyser();
      this.analyserNode.fftSize = 128;
      this.analyserNode.smoothingTimeConstant = 0.75;
      this.freqData = new Uint8Array(this.analyserNode.frequencyBinCount);

      this.analyserNode.connect(this.audioContext.destination);
      this.nextStartTime = 0;
      this.startPlaybackMonitor();
    }

    if (this.audioContext.state === 'suspended') {
      this.audioContext.resume();
    }
  }

  public addChunk(base64Data: string): void {
    try {
      this.initContext();
      if (!this.audioContext || !this.analyserNode) return;

      const float32Data = this.base64ToFloat32(base64Data);
      if (float32Data.length === 0) return;

      const buffer = this.audioContext.createBuffer(1, float32Data.length, 24000);
      buffer.copyToChannel(float32Data as any, 0);

      const source = this.audioContext.createBufferSource();
      source.buffer = buffer;
      source.connect(this.analyserNode);

      const currentTime = this.audioContext.currentTime;
      // Ensure smooth continuous gapless playback
      const startTime = Math.max(currentTime, this.nextStartTime);
      source.start(startTime);

      this.nextStartTime = startTime + buffer.duration;
      this.activeSources.push(source);

      if (this.onPlaybackStateChange) {
        this.onPlaybackStateChange(true);
      }

      source.onended = () => {
        const index = this.activeSources.indexOf(source);
        if (index > -1) {
          this.activeSources.splice(index, 1);
        }
        if (this.activeSources.length === 0 && this.onPlaybackStateChange) {
          this.onPlaybackStateChange(false);
        }
      };
    } catch (err) {
      console.error('[AudioStreamer] Error processing audio chunk:', err);
    }
  }

  /**
   * Immediately halts all playing and queued audio nodes (crucial for interruptions).
   */
  public stop(): void {
    for (const source of this.activeSources) {
      try {
        source.stop();
        source.disconnect();
      } catch {
        // Source may already have completed
      }
    }
    this.activeSources = [];
    this.nextStartTime = 0;

    if (this.onPlaybackStateChange) {
      this.onPlaybackStateChange(false);
    }
  }

  public getFrequencyData(): Uint8Array {
    if (this.analyserNode && this.isPlaying()) {
      this.analyserNode.getByteFrequencyData(this.freqData as any);
      return this.freqData;
    }
    return new Uint8Array(64);
  }

  public getVolume(): number {
    const data = this.getFrequencyData();
    let sum = 0;
    for (let i = 0; i < data.length; i++) {
      sum += data[i];
    }
    return data.length ? sum / data.length / 255 : 0;
  }

  public isPlaying(): boolean {
    if (!this.audioContext) return false;
    return this.activeSources.length > 0 && this.nextStartTime > this.audioContext.currentTime;
  }

  public cleanup(): void {
    this.stop();
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
    if (this.audioContext && this.audioContext.state !== 'closed') {
      this.audioContext.close();
      this.audioContext = null;
    }
  }

  private startPlaybackMonitor(): void {
    if (this.checkInterval) clearInterval(this.checkInterval);
    this.checkInterval = setInterval(() => {
      if (this.audioContext && this.activeSources.length === 0 && this.nextStartTime <= this.audioContext.currentTime) {
        // Drained
      }
    }, 150);
  }

  private base64ToFloat32(base64: string): Float32Array {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    const dataView = new DataView(bytes.buffer);
    const numSamples = Math.floor(bytes.length / 2);
    const float32 = new Float32Array(numSamples);

    for (let i = 0; i < numSamples; i++) {
      const int16 = dataView.getInt16(i * 2, true); // little-endian
      float32[i] = int16 < 0 ? int16 / 0x8000 : int16 / 0x7fff;
    }

    return float32;
  }
}
