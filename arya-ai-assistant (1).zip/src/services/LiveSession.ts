import { AudioRecorder } from '../audio/AudioRecorder';
import { AudioStreamer } from '../audio/AudioStreamer';
import { soundEffects } from '../audio/SoundEffects';
import { LiveState, ServerMessage, ToolActionData, VibeTheme } from '../types';

export type StateListener = (state: LiveState, message?: string) => void;
export type ToolListener = (action: ToolActionData) => void;
export type VibeListener = (vibe: VibeTheme) => void;

export class LiveSession {
  private ws: WebSocket | null = null;
  private recorder: AudioRecorder;
  private streamer: AudioStreamer;
  private state: LiveState = 'disconnected';
  private stateListeners: Set<StateListener> = new Set();
  private toolListeners: Set<ToolListener> = new Set();
  private vibeListeners: Set<VibeListener> = new Set();
  private isConnecting = false;

  constructor() {
    this.recorder = new AudioRecorder();
    this.streamer = new AudioStreamer();

    this.streamer.onPlaybackStateChange = (isPlaying) => {
      if (this.state === 'disconnected' || this.state === 'error') return;

      if (isPlaying) {
        this.setState('speaking', 'Arya is speaking');
      } else {
        // Playback finished, return to listening
        this.setState('listening', 'Arya is listening');
      }
    };
  }

  public subscribeState(listener: StateListener): () => void {
    this.stateListeners.add(listener);
    listener(this.state);
    return () => this.stateListeners.delete(listener);
  }

  public subscribeTool(listener: ToolListener): () => void {
    this.toolListeners.add(listener);
    return () => this.toolListeners.delete(listener);
  }

  public subscribeVibe(listener: VibeListener): () => void {
    this.vibeListeners.add(listener);
    return () => this.vibeListeners.delete(listener);
  }

  public getState(): LiveState {
    return this.state;
  }

  private setState(newState: LiveState, message?: string) {
    this.state = newState;
    this.stateListeners.forEach((fn) => fn(newState, message));
  }

  public async connect(): Promise<void> {
    if (this.state !== 'disconnected' && this.state !== 'error') {
      return;
    }

    if (this.isConnecting) return;
    this.isConnecting = true;

    try {
      this.setState('connecting', 'Connecting to Arya...');
      soundEffects.play('powerOn');

      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/live`;

      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = async () => {
        console.log('[LiveSession] WS Connected');
        try {
          // Initialize mic capture at 16kHz
          await this.recorder.start((base64Chunk) => {
            if (this.ws && this.ws.readyState === WebSocket.OPEN) {
              this.ws.send(
                JSON.stringify({
                  type: 'audio',
                  data: base64Chunk,
                })
              );
            }
          });
          this.setState('listening', 'Arya is listening to you');
          this.isConnecting = false;
        } catch (micErr: any) {
          console.error('[LiveSession] Microphone permission failed:', micErr);
          this.setState(
            'error',
            'Microphone access is required. Please allow microphone permissions and try again.'
          );
          this.disconnect();
        }
      };

      this.ws.onmessage = (event) => {
        try {
          const msg: ServerMessage = JSON.parse(event.data);
          this.handleServerMessage(msg);
        } catch (err) {
          console.error('[LiveSession] Error parsing message:', err);
        }
      };

      this.ws.onerror = (err) => {
        console.error('[LiveSession] WebSocket error:', err);
        this.setState('error', 'Connection to Arya encountered an error.');
        this.disconnect();
      };

      this.ws.onclose = () => {
        console.log('[LiveSession] WebSocket closed');
        if (this.state !== 'error') {
          this.setState('disconnected', 'Session ended.');
        }
        this.cleanup();
      };
    } catch (err: any) {
      console.error('[LiveSession] Connect failure:', err);
      this.setState('error', err?.message || 'Could not connect.');
      this.cleanup();
    } finally {
      this.isConnecting = false;
    }
  }

  private handleServerMessage(msg: ServerMessage) {
    switch (msg.type) {
      case 'audio':
        if (msg.data) {
          this.streamer.addChunk(msg.data);
        }
        break;

      case 'interrupted':
        console.log('[LiveSession] Interruption received: halting speech playback');
        this.streamer.stop();
        this.setState('listening', 'Arya paused to hear you');
        break;

      case 'turn_complete':
        // Model finished generating stream chunks
        break;

      case 'tool_action':
        this.handleToolAction(msg);
        break;

      case 'error':
        console.error('[LiveSession] Server reported error:', msg.error);
        this.setState('error', msg.error || 'Server error occurred.');
        break;

      case 'status':
        if (msg.status === 'ready' && this.state === 'connecting') {
          this.setState('listening', msg.message || 'Arya is listening');
        }
        break;
    }
  }

  private handleToolAction(msg: ServerMessage) {
    if (!msg.tool) return;

    const actionData: ToolActionData = {
      id: Math.random().toString(36).substring(2, 9),
      tool: msg.tool,
      args: msg.args || {},
      timestamp: Date.now(),
    };

    console.log('[LiveSession] Executing tool action:', actionData);

    if (msg.tool === 'openWebsite' && msg.args?.url) {
      try {
        // Attempt to open in a new tab
        window.open(msg.args.url, '_blank', 'noopener,noreferrer');
      } catch (err) {
        console.warn('[LiveSession] Popup blocked:', err);
      }
    } else if (msg.tool === 'changeVibe') {
      const vibe = msg.args?.vibe as VibeTheme;
      if (vibe) {
        this.vibeListeners.forEach((fn) => fn(vibe));
      }
      if (msg.args?.sound) {
        const soundName = msg.args.sound;
        if (['sparkle', 'wink', 'heartbeat', 'chime'].includes(soundName)) {
          soundEffects.play(soundName as any);
        }
      }
    }

    this.toolListeners.forEach((fn) => fn(actionData));
  }

  public disconnect(): void {
    soundEffects.play('powerOff');
    this.cleanup();
    this.setState('disconnected', 'Arya is resting. Tap to connect.');
  }

  private cleanup(): void {
    this.isConnecting = false;
    this.streamer.stop();
    this.recorder.stop();

    if (this.ws) {
      this.ws.onclose = null;
      this.ws.onerror = null;
      this.ws.onmessage = null;
      if (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING) {
        this.ws.close();
      }
      this.ws = null;
    }
  }

  /**
   * Frequency and volume data for visualizer
   */
  public getVisualizerData(): {
    frequencies: Uint8Array;
    volume: number;
    mode: 'input' | 'output' | 'idle';
  } {
    if (this.state === 'speaking' && this.streamer.isPlaying()) {
      return {
        frequencies: this.streamer.getFrequencyData(),
        volume: this.streamer.getVolume(),
        mode: 'output',
      };
    } else if (this.state === 'listening') {
      return {
        frequencies: this.recorder.getFrequencyData(),
        volume: this.recorder.getVolume(),
        mode: 'input',
      };
    }
    return {
      frequencies: new Uint8Array(64),
      volume: 0,
      mode: 'idle',
    };
  }
}
