import React, { useEffect, useRef, useState } from 'react';
import { LiveSession } from './services/LiveSession';
import { OrbVisualizer } from './components/OrbVisualizer';
import { AudioWaveform } from './components/AudioWaveform';
import { StatusIndicator } from './components/StatusIndicator';
import { ToolActionBanner } from './components/ToolActionBanner';
import { AryaHUD } from './components/AryaHUD';
import { VoiceSuggestionsDrawer } from './components/VoiceSuggestionsDrawer';
import { VIBE_THEMES } from './theme';
import { LiveState, ToolActionData, VibeConfig, VibeTheme } from './types';
import { soundEffects } from './audio/SoundEffects';

export default function App() {
  const [liveState, setLiveState] = useState<LiveState>('disconnected');
  const [statusMessage, setStatusMessage] = useState<string>('Arya is resting. Tap to connect.');
  const [currentVibe, setCurrentVibe] = useState<VibeConfig>(VIBE_THEMES['matrix-emerald']);
  const [lastAction, setLastAction] = useState<ToolActionData | null>(null);
  const [showSuggestions, setShowSuggestions] = useState(false);

  // Audio visualization data states
  const [volume, setVolume] = useState<number>(0);
  const [frequencies, setFrequencies] = useState<Uint8Array>(new Uint8Array(64));

  const sessionRef = useRef<LiveSession | null>(null);
  const animFrameRef = useRef<number | null>(null);

  useEffect(() => {
    // Initialize session service
    const session = new LiveSession();
    sessionRef.current = session;

    const unsubState = session.subscribeState((newState, msg) => {
      setLiveState(newState);
      if (msg) setStatusMessage(msg);
    });

    const unsubTool = session.subscribeTool((action) => {
      setLastAction(action);
    });

    const unsubVibe = session.subscribeVibe((newVibeKey) => {
      if (VIBE_THEMES[newVibeKey]) {
        setCurrentVibe(VIBE_THEMES[newVibeKey]);
      }
    });

    // Real-time audio reactive loop
    const updateAudioData = () => {
      if (sessionRef.current) {
        const data = sessionRef.current.getVisualizerData();
        setVolume(data.volume);
        setFrequencies(data.frequencies);
      }
      animFrameRef.current = requestAnimationFrame(updateAudioData);
    };

    animFrameRef.current = requestAnimationFrame(updateAudioData);

    return () => {
      unsubState();
      unsubTool();
      unsubVibe();
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
      session.disconnect();
    };
  }, []);

  const handleToggleSession = async () => {
    if (!sessionRef.current) return;

    if (liveState === 'disconnected' || liveState === 'error') {
      await sessionRef.current.connect();
    } else {
      sessionRef.current.disconnect();
    }
  };

  const handleSelectVibe = (themeKey: VibeTheme) => {
    if (VIBE_THEMES[themeKey]) {
      setCurrentVibe(VIBE_THEMES[themeKey]);
      soundEffects.play('sparkle');
    }
  };

  return (
    <main
      id="arya-app-root"
      className="relative w-full h-screen h-[100dvh] overflow-hidden flex flex-col justify-between items-center text-white select-none transition-all duration-1000 font-sans"
      style={{
        background: currentVibe.bgGradient,
      }}
    >
      {/* Dynamic ambient color mesh / radial background */}
      <div
        className="absolute inset-0 pointer-events-none opacity-45 mix-blend-screen transition-opacity duration-1000"
        style={{
          backgroundImage: `radial-gradient(circle at 50% 45%, ${currentVibe.glow} 0%, transparent 65%)`,
        }}
      />

      {/* Top HUD Navigation Bar */}
      <AryaHUD
        currentVibe={currentVibe}
        onSelectVibe={handleSelectVibe}
        onOpenSuggestions={() => setShowSuggestions(true)}
      />

      {/* Tool Call HUD Alert Banner */}
      <div className="absolute top-16 z-30 w-full flex justify-center pointer-events-none">
        <ToolActionBanner lastAction={lastAction} vibe={currentVibe} />
      </div>

      {/* Central Visualizer & Mic Core */}
      <div className="flex-1 flex flex-col items-center justify-center relative z-20 my-auto py-2">
        <OrbVisualizer
          state={liveState}
          vibe={currentVibe}
          volume={volume}
          frequencies={frequencies}
          onToggle={handleToggleSession}
        />

        {/* Live Status Pill & Subtitle */}
        <div className="mt-4">
          <StatusIndicator
            state={liveState}
            vibe={currentVibe}
            statusMessage={statusMessage}
          />
        </div>
      </div>

      {/* Bottom Waveform flush to bottom edge */}
      <footer id="arya-footer" className="w-full flex justify-center items-end z-20 pointer-events-none">
        <AudioWaveform
          state={liveState}
          vibe={currentVibe}
          frequencies={frequencies}
          volume={volume}
        />
      </footer>

      {/* Voice Prompt Suggestions Drawer */}
      <VoiceSuggestionsDrawer
        isOpen={showSuggestions}
        onClose={() => setShowSuggestions(false)}
        vibe={currentVibe}
      />
    </main>
  );
}
