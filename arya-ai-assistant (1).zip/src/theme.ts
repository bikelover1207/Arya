import { VibeConfig, VibeTheme } from './types';

export const VIBE_THEMES: Record<VibeTheme, VibeConfig> = {
  'electric-violet': {
    id: 'electric-violet',
    name: 'Electric Violet',
    primary: 'from-violet-500 via-fuchsia-500 to-indigo-600',
    glow: 'rgba(168, 85, 247, 0.45)',
    bgGradient: 'radial-gradient(ellipse at 50% 45%, rgba(139, 92, 246, 0.18) 0%, rgba(15, 10, 30, 0.95) 75%, #07040d 100%)',
    orbCore: 'rgba(168, 85, 247, 0.85)',
    accent: '#c084fc',
  },
  'neon-pink': {
    id: 'neon-pink',
    name: 'Neon Pink',
    primary: 'from-pink-500 via-rose-500 to-fuchsia-600',
    glow: 'rgba(244, 63, 94, 0.5)',
    bgGradient: 'radial-gradient(ellipse at 50% 45%, rgba(244, 63, 94, 0.18) 0%, rgba(28, 8, 18, 0.95) 75%, #0a0307 100%)',
    orbCore: 'rgba(244, 63, 94, 0.85)',
    accent: '#fb7185',
  },
  'cyber-blue': {
    id: 'cyber-blue',
    name: 'Cyber Blue',
    primary: 'from-cyan-400 via-teal-400 to-blue-600',
    glow: 'rgba(6, 182, 212, 0.45)',
    bgGradient: 'radial-gradient(ellipse at 50% 45%, rgba(6, 182, 212, 0.18) 0%, rgba(5, 20, 32, 0.95) 75%, #03080e 100%)',
    orbCore: 'rgba(6, 182, 212, 0.85)',
    accent: '#38bdf8',
  },
  'sunset-gold': {
    id: 'sunset-gold',
    name: 'Sunset Gold',
    primary: 'from-amber-400 via-orange-500 to-rose-600',
    glow: 'rgba(245, 158, 11, 0.45)',
    bgGradient: 'radial-gradient(ellipse at 50% 45%, rgba(245, 158, 11, 0.18) 0%, rgba(28, 16, 8, 0.95) 75%, #0a0603 100%)',
    orbCore: 'rgba(245, 158, 11, 0.85)',
    accent: '#fbbf24',
  },
  'matrix-emerald': {
    id: 'matrix-emerald',
    name: 'Matrix Emerald',
    primary: 'from-emerald-400 via-teal-400 to-emerald-600',
    glow: 'rgba(52, 211, 153, 0.45)',
    bgGradient: 'radial-gradient(ellipse at 50% 45%, rgba(45, 212, 191, 0.28) 0%, rgba(13, 42, 33, 0.95) 55%, #051812 85%, #020b08 100%)',
    orbCore: 'rgba(52, 211, 153, 0.9)',
    accent: '#34d399',
  },
};
