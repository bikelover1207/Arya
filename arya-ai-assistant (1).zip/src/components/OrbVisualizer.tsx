import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { Mic, Sparkles, Power } from 'lucide-react';
import { LiveState, VibeConfig } from '../types';

interface OrbVisualizerProps {
  state: LiveState;
  vibe: VibeConfig;
  volume: number;
  frequencies: Uint8Array;
  onToggle: () => void;
}

export const OrbVisualizer: React.FC<OrbVisualizerProps> = ({
  state,
  vibe,
  volume,
  frequencies,
  onToggle,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const phaseRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = 440;
    canvas.width = size;
    canvas.height = size;

    const render = () => {
      ctx.clearRect(0, 0, size, size);

      const cx = size / 2;
      const cy = size / 2;
      const isLive = state === 'listening' || state === 'speaking';
      const dynamicBoost = volume * 45;

      phaseRef.current += state === 'connecting' ? 0.06 : state === 'speaking' ? 0.04 : 0.018;

      // 1. Draw central translucent disk halo
      ctx.beginPath();
      const haloRadius = 115 + (isLive ? dynamicBoost * 0.4 : 0);
      ctx.arc(cx, cy, haloRadius, 0, Math.PI * 2);
      ctx.fillStyle = vibe.accent;
      ctx.globalAlpha = isLive ? 0.22 + volume * 0.15 : 0.14;
      ctx.fill();

      // 2. Draw organic wavy acoustic ribbons
      const numRibbons = state === 'speaking' ? 4 : 3;
      const baseRadii = [118, 138, 158, 178];

      for (let r = 0; r < numRibbons; r++) {
        ctx.beginPath();
        const baseR = baseRadii[r] + (isLive ? dynamicBoost * (0.6 - r * 0.1) : 0);
        const steps = 72;

        for (let i = 0; i <= steps; i++) {
          const angle = (i / steps) * Math.PI * 2;
          const freqIndex = (i * 2 + r * 6) % Math.max(1, frequencies.length);
          const freqVal = (frequencies[freqIndex] || 0) / 255;

          // Organic harmonic waveforms resembling fluid sound resonance
          const wave1 = Math.sin(angle * 4 + phaseRef.current * 1.5 + r * 1.3);
          const wave2 = Math.cos(angle * 2 - phaseRef.current * 0.8 + r);
          const amp = isLive ? (freqVal * 24 + 10) : 6;
          const deform = (wave1 * 0.65 + wave2 * 0.35) * amp;

          const radius = baseR + deform;
          const x = cx + Math.cos(angle) * radius;
          const y = cy + Math.sin(angle) * radius;

          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }

        ctx.closePath();

        ctx.strokeStyle = vibe.accent;
        ctx.lineWidth = 1.4;
        ctx.globalAlpha = isLive ? Math.max(0.2, 0.65 - r * 0.12) : 0.25 - r * 0.05;
        ctx.stroke();

        // Very subtle fill between innermost ribbon and halo
        if (r === 0) {
          ctx.fillStyle = vibe.accent;
          ctx.globalAlpha = isLive ? 0.08 : 0.04;
          ctx.fill();
        }
      }

      // 3. Subtle floating luminous orbital particle dots on curves
      const dotAngles = [
        phaseRef.current * 0.4 + 0.8,
        phaseRef.current * 0.35 + 3.2,
        -phaseRef.current * 0.3 + 5.1,
      ];
      const dotRadii = [135, 150, 165];

      for (let d = 0; d < 3; d++) {
        const angle = dotAngles[d];
        const r = dotRadii[d] + (isLive ? dynamicBoost * 0.3 : 0);
        const px = cx + Math.cos(angle) * r;
        const py = cy + Math.sin(angle) * r;

        ctx.beginPath();
        ctx.arc(px, py, 2.2, 0, Math.PI * 2);
        ctx.fillStyle = vibe.accent;
        ctx.globalAlpha = isLive ? 0.8 : 0.4;
        ctx.shadowColor = vibe.accent;
        ctx.shadowBlur = 6;
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      ctx.globalAlpha = 1.0;
      animFrameRef.current = requestAnimationFrame(render);
    };

    animFrameRef.current = requestAnimationFrame(render);

    return () => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, [state, vibe, volume, frequencies]);

  const isLive = state === 'listening' || state === 'speaking';
  const isConnecting = state === 'connecting';

  return (
    <div id="arya-orb-container" className="relative flex items-center justify-center select-none">
      {/* Background radiant ambient glow */}
      <motion.div
        animate={{
          scale: isLive ? [1, 1.12 + volume * 0.25, 1] : [0.95, 1.05, 0.95],
          opacity: state === 'disconnected' ? 0.25 : 0.6 + volume * 0.3,
        }}
        transition={{
          duration: state === 'speaking' ? 0.9 : 3,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        style={{
          boxShadow: `0 0 130px 50px ${vibe.glow}`,
          backgroundColor: vibe.orbCore,
        }}
        className="absolute w-60 h-60 rounded-full filter blur-3xl pointer-events-none transition-colors duration-700"
      />

      {/* Interactive HTML5 Audio-reactive Canvas */}
      <canvas
        ref={canvasRef}
        className="w-[360px] h-[360px] sm:w-[440px] sm:h-[440px] pointer-events-none z-10"
      />

      {/* Central Interactive Core / Dual-Ring Mic Button matching screenshot */}
      <motion.button
        id="arya-core-button"
        whileHover={{ scale: 1.04 }}
        whileTap={{ scale: 0.96 }}
        onClick={onToggle}
        aria-label={isLive ? 'Disconnect from Arya' : 'Connect to Arya'}
        className="absolute z-20 w-36 h-36 sm:w-44 sm:h-44 rounded-full flex items-center justify-center cursor-pointer transition-all duration-500 shadow-2xl focus:outline-none"
        style={{
          background:
            state === 'disconnected'
              ? 'rgba(52, 211, 153, 0.25)'
              : 'rgba(52, 211, 153, 0.85)',
          boxShadow: isLive
            ? `0 0 45px ${vibe.glow}, inset 0 0 20px rgba(255, 255, 255, 0.3)`
            : '0 0 25px rgba(0,0,0,0.6)',
          border: `2px solid ${vibe.accent}`,
        }}
      >
        {/* Inner Dark Core Disc */}
        <div
          className="w-24 h-24 sm:w-28 sm:h-28 rounded-full flex flex-col items-center justify-center transition-all duration-300 shadow-inner"
          style={{
            background: 'radial-gradient(circle, #0c2e24 0%, #061913 100%)',
            border: '1.5px solid rgba(255, 255, 255, 0.25)',
          }}
        >
          {/* Animated pulse halo when speaking */}
          {isLive && (
            <motion.div
              animate={{
                scale: [1, 1.25, 1],
                opacity: [0.5, 0, 0.5],
              }}
              transition={{
                duration: state === 'speaking' ? 0.9 : 2,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
              className="absolute inset-0 rounded-full border border-white/40 pointer-events-none"
            />
          )}

          {/* Status Icon */}
          <div className="relative z-10 flex flex-col items-center justify-center">
            {isConnecting ? (
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 1.2, ease: 'linear' }}
              >
                <Sparkles className="w-8 h-8 text-white drop-shadow-md" />
              </motion.div>
            ) : state === 'disconnected' ? (
              <Power className="w-8 h-8 text-zinc-300 group-hover:text-white transition-colors" />
            ) : (
              <motion.div
                animate={state === 'speaking' ? { scale: [1, 1.12, 1] } : {}}
                transition={{ repeat: Infinity, duration: 0.6 }}
              >
                <Mic className="w-8 h-8 sm:w-9 sm:h-9 text-white stroke-[2.2] drop-shadow" />
              </motion.div>
            )}

            {/* Micro text label "ARYA" */}
            <span className="text-[11px] uppercase font-mono tracking-[0.2em] text-white font-extrabold mt-1">
              ARYA
            </span>
          </div>
        </div>
      </motion.button>
    </div>
  );
};
