import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ExternalLink, Sparkles, Clock, Palette, X } from 'lucide-react';
import { ToolActionData, VibeConfig } from '../types';

interface ToolActionBannerProps {
  lastAction: ToolActionData | null;
  vibe: VibeConfig;
}

export const ToolActionBanner: React.FC<ToolActionBannerProps> = ({ lastAction, vibe }) => {
  const [visible, setVisible] = useState(false);
  const [currentAction, setCurrentAction] = useState<ToolActionData | null>(null);

  useEffect(() => {
    if (lastAction) {
      setCurrentAction(lastAction);
      setVisible(true);
      const timer = setTimeout(() => {
        setVisible(false);
      }, 7000);
      return () => clearTimeout(timer);
    }
  }, [lastAction]);

  if (!currentAction) return null;

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          id="tool-action-banner"
          initial={{ opacity: 0, y: -20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -15, scale: 0.95 }}
          transition={{ duration: 0.3, ease: 'easeOut' }}
          className="w-full max-w-md px-4 pointer-events-auto"
        >
          <div
            className="flex items-center justify-between gap-3 p-3 rounded-2xl border backdrop-blur-xl shadow-xl transition-all"
            style={{
              backgroundColor: 'rgba(18, 12, 30, 0.85)',
              borderColor: `${vibe.accent}66`,
              boxShadow: `0 8px 30px ${vibe.glow}`,
            }}
          >
            <div className="flex items-center gap-3 overflow-hidden">
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border"
                style={{
                  backgroundColor: `${vibe.accent}22`,
                  borderColor: `${vibe.accent}55`,
                  color: vibe.accent,
                }}
              >
                {currentAction.tool === 'openWebsite' ? (
                  <ExternalLink className="w-4 h-4" />
                ) : currentAction.tool === 'changeVibe' ? (
                  <Palette className="w-4 h-4" />
                ) : (
                  <Clock className="w-4 h-4" />
                )}
              </div>

              <div className="flex flex-col text-left truncate">
                <span className="text-[11px] font-mono uppercase tracking-wider text-zinc-400 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-amber-400" />
                  Arya Triggered Tool: {currentAction.tool}
                </span>

                {currentAction.tool === 'openWebsite' && (
                  <span className="text-sm font-semibold text-white truncate">
                    {currentAction.args.title || currentAction.args.url}
                  </span>
                )}

                {currentAction.tool === 'changeVibe' && (
                  <span className="text-sm font-semibold text-white">
                    Shifted mood to {currentAction.args.vibe?.replace('-', ' ')}
                  </span>
                )}

                {currentAction.tool === 'getSystemInfo' && (
                  <span className="text-sm font-semibold text-white">
                    Synced real-time calendar & clock
                  </span>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {currentAction.tool === 'openWebsite' && currentAction.args.url && (
                <a
                  href={currentAction.args.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold text-white flex items-center gap-1 transition-transform hover:scale-105 active:scale-95"
                  style={{
                    backgroundColor: vibe.accent,
                    boxShadow: `0 0 12px ${vibe.glow}`,
                  }}
                >
                  Visit
                  <ExternalLink className="w-3 h-3" />
                </a>
              )}

              <button
                onClick={() => setVisible(false)}
                className="p-1 rounded-md text-zinc-400 hover:text-white transition-colors"
                aria-label="Dismiss banner"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
