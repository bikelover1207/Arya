import React, { useEffect, useRef } from 'react';
import { LiveState, VibeConfig } from '../types';

interface AudioWaveformProps {
  state: LiveState;
  vibe: VibeConfig;
  frequencies: Uint8Array;
  volume: number;
}

export const AudioWaveform: React.FC<AudioWaveformProps> = ({
  state,
  vibe,
  frequencies,
  volume,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animRef = useRef<number | null>(null);
  const phaseRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = (canvas.width = canvas.parentElement?.clientWidth || 640);
    let height = (canvas.height = 90);

    const handleResize = () => {
      if (canvas.parentElement) {
        width = canvas.width = canvas.parentElement.clientWidth;
      }
    };

    window.addEventListener('resize', handleResize);

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      const isLive = state === 'listening' || state === 'speaking';
      phaseRef.current += isLive ? 0.045 : 0.015;

      const bars = 42;
      const barSpacing = width / bars;
      const barWidth = Math.max(3, barSpacing * 0.68);
      const radius = barWidth / 2;

      for (let i = 0; i < bars; i++) {
        // Mirrored spectrum effect from center outwards
        const distFromCenter = Math.abs(i - bars / 2) / (bars / 2);
        const freqIndex = Math.floor((1 - distFromCenter) * (frequencies.length / 2));
        const freqVal = (frequencies[freqIndex] || 0) / 255;

        let barHeight = 12;
        if (isLive) {
          // Dynamic contour matching the screenshot's wave pattern
          const sineNoise = Math.sin(i * 0.35 + phaseRef.current) * 8;
          const boost = state === 'speaking' ? 1.5 : 1.0;
          barHeight = Math.max(
            10,
            freqVal * 60 + volume * 25 + (sineNoise + 12) * boost
          );
        } else if (state === 'connecting') {
          barHeight = 10 + Math.abs(Math.sin(i * 0.25 + phaseRef.current * 2)) * 30;
        } else {
          barHeight = 8 + Math.abs(Math.sin(i * 0.2 + phaseRef.current)) * 8;
        }

        const x = i * barSpacing + (barSpacing - barWidth) / 2;
        const y = height - barHeight; // Anchored at the bottom edge

        ctx.beginPath();
        // Top corners rounded, bottom corners flat
        if (typeof ctx.roundRect === 'function') {
          ctx.roundRect(x, y, barWidth, barHeight + 5, [radius, radius, 0, 0]);
        } else {
          ctx.rect(x, y, barWidth, barHeight);
        }

        // Gradient for equalizer bars
        const grad = ctx.createLinearGradient(0, y, 0, height);
        grad.addColorStop(0, '#6ee7b7');
        grad.addColorStop(0.4, vibe.accent);
        grad.addColorStop(1, '#059669');

        ctx.fillStyle = grad;
        ctx.globalAlpha = isLive ? 0.9 : 0.45;
        ctx.fill();
      }

      ctx.globalAlpha = 1.0;
      animRef.current = requestAnimationFrame(render);
    };

    animRef.current = requestAnimationFrame(render);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animRef.current) {
        cancelAnimationFrame(animRef.current);
      }
    };
  }, [state, vibe, frequencies, volume]);

  return (
    <div id="audio-waveform-container" className="w-full max-w-2xl h-[90px] flex items-end justify-center px-4 overflow-hidden">
      <canvas ref={canvasRef} className="w-full h-full block" />
    </div>
  );
};
