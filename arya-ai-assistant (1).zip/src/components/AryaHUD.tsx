import React from 'react';
import { Sparkles, HelpCircle, Palette } from 'lucide-react';
import { VibeConfig, VibeTheme } from '../types';
import { VIBE_THEMES } from '../theme';

interface AryaHUDProps {
  currentVibe: VibeConfig;
  onSelectVibe: (theme: VibeTheme) => void;
  onOpenSuggestions: () => void;
}

export const AryaHUD: React.FC<AryaHUDProps> = ({
  currentVibe,
  onSelectVibe,
  onOpenSuggestions,
}) => {
  const [showVibeMenu, setShowVibeMenu] = React.useState(false);

  return (
    <header id="arya-hud-header" className="w-full max-w-7xl px-6 sm:px-10 py-5 flex items-center justify-between z-30 select-none">
      {/* Brand Identity */}
      <div className="flex items-center gap-3">
        <div
          className="w-11 h-11 rounded-2xl flex items-center justify-center font-extrabold text-white text-lg shadow-lg transition-all duration-500 shrink-0"
          style={{
            backgroundColor: currentVibe.accent,
            boxShadow: `0 0 22px ${currentVibe.glow}`,
          }}
        >
          A
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-extrabold tracking-tight text-white font-sans">
              Arya
            </h1>
            <span
              className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded-full border"
              style={{
                borderColor: `${currentVibe.accent}66`,
                color: currentVibe.accent,
                backgroundColor: 'rgba(255, 255, 255, 0.05)',
              }}
            >
              LIVE AUDIO
            </span>
          </div>
          <p className="text-xs text-zinc-400 font-medium">
            Confident • Witty • Sassy Companion
          </p>
        </div>
      </div>

      {/* Right HUD Controls */}
      <div className="flex items-center gap-2.5 relative">
        {/* Vibe Palette Switcher */}
        <div className="relative">
          <button
            id="vibe-selector-toggle"
            onClick={() => setShowVibeMenu((prev) => !prev)}
            className="px-3.5 py-2 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 text-zinc-200 hover:text-white flex items-center gap-2 text-xs font-medium transition-all backdrop-blur-md"
            aria-label="Change visual vibe"
          >
            <Palette className="w-4 h-4" style={{ color: currentVibe.accent }} />
            <span>Vibe</span>
          </button>

          {showVibeMenu && (
            <>
              <div
                className="fixed inset-0 z-40"
                onClick={() => setShowVibeMenu(false)}
              />
              <div
                className="absolute right-0 mt-2 z-50 w-48 rounded-2xl border border-white/15 bg-zinc-950/95 p-2 shadow-2xl backdrop-blur-xl space-y-1"
                style={{ borderColor: `${currentVibe.accent}44` }}
              >
                <div className="px-2.5 py-1 text-[10px] font-mono uppercase text-zinc-400 font-semibold tracking-wider">
                  Visual Themes
                </div>
                {(Object.keys(VIBE_THEMES) as VibeTheme[]).map((themeKey) => {
                  const theme = VIBE_THEMES[themeKey];
                  const isSelected = themeKey === currentVibe.id;
                  return (
                    <button
                      key={themeKey}
                      onClick={() => {
                        onSelectVibe(themeKey);
                        setShowVibeMenu(false);
                      }}
                      className={`w-full flex items-center gap-2 px-2.5 py-2 rounded-xl text-xs font-medium text-left transition-colors ${
                        isSelected
                          ? 'bg-white/15 text-white font-semibold'
                          : 'text-zinc-300 hover:bg-white/5 hover:text-white'
                      }`}
                    >
                      <span
                        className="w-3 h-3 rounded-full shrink-0 shadow-sm"
                        style={{ backgroundColor: theme.accent }}
                      />
                      <span>{theme.name}</span>
                    </button>
                  );
                })}
              </div>
            </>
          )}
        </div>

        {/* Ideas / Prompt inspirations */}
        <button
          id="suggestions-toggle-btn"
          onClick={onOpenSuggestions}
          className="px-3.5 py-2 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 text-zinc-200 hover:text-white flex items-center gap-2 text-xs font-medium transition-all backdrop-blur-md"
          aria-label="Voice conversation ideas"
        >
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>Ideas</span>
        </button>
      </div>
    </header>
  );
};
