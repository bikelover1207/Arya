import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Radio, Volume2, AlertCircle, Sparkles } from 'lucide-react';
import { LiveState, VibeConfig } from '../types';

interface StatusIndicatorProps {
  state: LiveState;
  vibe: VibeConfig;
  statusMessage?: string;
}

export const StatusIndicator: React.FC<StatusIndicatorProps> = ({
  state,
  vibe,
  statusMessage,
}) => {
  const getBadgeContent = () => {
    switch (state) {
      case 'connecting':
        return {
          icon: Sparkles,
          label: 'CONNECTING',
          color: 'text-amber-400',
          dotColor: 'bg-amber-400',
          desc: statusMessage || 'Connecting to Arya...',
        };
      case 'listening':
        return {
          icon: Radio,
          label: 'LISTENING',
          color: 'text-emerald-400',
          dotColor: 'bg-emerald-400',
          desc: statusMessage || 'Arya is listening... Go ahead and speak',
        };
      case 'speaking':
        return {
          icon: Volume2,
          label: 'ARYA SPEAKING',
          color: 'text-[#f43f5e]',
          dotColor: 'bg-[#f43f5e]',
          desc: statusMessage || 'Arya is speaking',
        };
      case 'error':
        return {
          icon: AlertCircle,
          label: 'ATTENTION',
          color: 'text-rose-400',
          dotColor: 'bg-rose-500',
          desc: statusMessage || 'Microphone or connection failed.',
        };
      case 'disconnected':
      default:
        return {
          icon: Sparkles,
          label: 'STANDBY',
          color: 'text-zinc-400',
          dotColor: 'bg-zinc-500',
          desc: 'Tap the core orb to start talking with Arya',
        };
    }
  };

  const badge = getBadgeContent();
  const Icon = badge.icon;

  return (
    <div id="status-indicator-section" className="flex flex-col items-center gap-2 text-center select-none px-4">
      {/* Pill Badge matching screenshot */}
      <motion.div
        layout
        className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-mono tracking-wider border backdrop-blur-md transition-colors duration-500"
        style={{
          backgroundColor: 'rgba(18, 28, 24, 0.75)',
          borderColor: 'rgba(255, 255, 255, 0.12)',
        }}
      >
        {/* Glowing circular dot */}
        <span className={`w-2 h-2 rounded-full ${badge.dotColor} shadow-sm shrink-0`} />

        {/* Status text with Icon */}
        <span className={`font-bold flex items-center gap-1.5 ${badge.color}`}>
          <Icon className="w-3.5 h-3.5" />
          {badge.label}
        </span>

        {/* Separator and PCM info */}
        {state !== 'disconnected' && (
          <>
            <span className="w-[1px] h-3 bg-white/20" />
            <span className="text-zinc-400 text-[11px] font-mono">
              24kHz PCM
            </span>
          </>
        )}
      </motion.div>

      {/* Main Subtitle Description */}
      <AnimatePresence mode="wait">
        <motion.p
          key={badge.desc}
          initial={{ opacity: 0, y: 3 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -3 }}
          transition={{ duration: 0.18 }}
          className="text-sm text-zinc-200 font-medium tracking-wide max-w-sm"
        >
          {badge.desc}
        </motion.p>
      </AnimatePresence>
    </div>
  );
};
