import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Sparkles, MessageCircle, ExternalLink, Zap } from 'lucide-react';
import { VibeConfig } from '../types';

interface VoiceSuggestionsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  vibe: VibeConfig;
}

const SUGGESTIONS = [
  {
    category: 'Sassy & Playful Banter',
    prompts: [
      '“Arya, tell me what you really think of me.”',
      '“Flirt with me for a minute, don’t hold back.”',
      '“Give me your boldest, most sarcastic life advice.”',
      '“Who is the most gorgeous AI on the planet?”',
    ],
  },
  {
    category: 'Interactive Tools & Browser Actions',
    prompts: [
      '“Arya, open YouTube for me!”',
      '“Can you pull up Spotify in my browser?”',
      '“What time and day is it right now?”',
      '“Change your vibe to Cyber Blue and play a sound!”',
    ],
  },
  {
    category: 'Smart & Witty Brain',
    prompts: [
      '“Give me a savage reality check about procrastination.”',
      '“Tell me a witty, unhinged bedtime story.”',
      '“Hypeman speech, Arya! I have a huge challenge today.”',
    ],
  },
];

export const VoiceSuggestionsDrawer: React.FC<VoiceSuggestionsDrawerProps> = ({
  isOpen,
  onClose,
  vibe,
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm"
          />

          {/* Modal / Sheet */}
          <motion.div
            id="voice-suggestions-drawer"
            initial={{ opacity: 0, y: 50, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 40, scale: 0.96 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed z-50 bottom-0 left-0 right-0 sm:bottom-auto sm:top-1/2 sm:left-1/2 sm:-translate-x-1/2 sm:-translate-y-1/2 w-full sm:max-w-lg max-h-[85vh] rounded-t-3xl sm:rounded-3xl border border-white/15 bg-zinc-950/95 p-6 overflow-y-auto shadow-2xl backdrop-blur-xl"
            style={{
              borderColor: `${vibe.accent}44`,
              boxShadow: `0 20px 60px ${vibe.glow}`,
            }}
          >
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div className="flex items-center gap-2.5">
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center text-white"
                  style={{ backgroundColor: vibe.accent }}
                >
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-1.5">
                    Conversing with Arya
                  </h3>
                  <p className="text-xs text-zinc-400">
                    Pure voice-to-voice interaction • Just speak naturally
                  </p>
                </div>
              </div>

              <button
                onClick={onClose}
                className="p-1.5 rounded-full hover:bg-white/10 text-zinc-400 hover:text-white transition-colors"
                aria-label="Close dialog"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-5">
              <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-xs text-zinc-300 leading-relaxed">
                <span className="font-semibold text-white">Notice:</span> Arya has no text chatbox—she talks, listens, and reacts in real-time through audio streaming. Try speaking any of these lines out loud!
              </div>

              {SUGGESTIONS.map((section, idx) => (
                <div key={idx} className="space-y-2">
                  <h4 className="text-xs font-mono uppercase tracking-wider text-zinc-400 font-semibold flex items-center gap-1.5">
                    <Zap className="w-3 h-3 text-amber-400" />
                    {section.category}
                  </h4>
                  <div className="grid grid-cols-1 gap-2">
                    {section.prompts.map((prompt, pIdx) => (
                      <div
                        key={pIdx}
                        className="p-3 rounded-xl bg-white/[0.04] border border-white/5 hover:border-white/20 transition-all text-sm text-zinc-200 flex items-start gap-2.5"
                      >
                        <MessageCircle className="w-4 h-4 shrink-0 mt-0.5 text-zinc-400" />
                        <span className="font-medium italic">{prompt}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 pt-4 border-t border-white/10 flex justify-end">
              <button
                onClick={onClose}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl font-semibold text-sm text-white transition-transform active:scale-95"
                style={{ backgroundColor: vibe.accent }}
              >
                Got it, let’s talk!
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
