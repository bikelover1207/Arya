export type LiveState = 'disconnected' | 'connecting' | 'listening' | 'speaking' | 'error';

export type VibeTheme = 'neon-pink' | 'cyber-blue' | 'electric-violet' | 'sunset-gold' | 'matrix-emerald';

export interface VibeConfig {
  id: VibeTheme;
  name: string;
  primary: string; // Tailwind color or hex
  glow: string;
  bgGradient: string;
  orbCore: string;
  accent: string;
}

export interface ToolActionData {
  id: string;
  tool: string;
  args: Record<string, any>;
  timestamp: number;
}

export interface ServerMessage {
  type: 'status' | 'audio' | 'interrupted' | 'turn_complete' | 'tool_action' | 'error' | 'pong';
  status?: string;
  message?: string;
  data?: string; // base64 audio
  error?: string;
  tool?: string;
  args?: Record<string, any>;
}

export interface ClientMessage {
  type: 'audio' | 'ping';
  data?: string; // base64 audio
}
